/**
 * @file main.c
 *
 * @date 7 oct. 2016
 * @author jilias
 */

#include "player_manager.h"
#include "board_view.h"
#include "board.h"



void Game_init (void)
{
  // TODO: initialiser tous les modules
}

void Game_free (void)
{
  // TODO: libérer tous les modules
}

void Game_loop (void)
{
	// TODO: à compléter
}
