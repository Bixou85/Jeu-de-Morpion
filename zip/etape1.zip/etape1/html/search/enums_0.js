var searchData=
[
  ['gameresult_0',['GameResult',['../board_8h.html#a41741953d704b743544ce6383c27c7c6',1,'board.h']]]
];
