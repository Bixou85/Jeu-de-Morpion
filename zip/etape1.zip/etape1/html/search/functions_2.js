var searchData=
[
  ['game_5ffree_0',['Game_free',['../game_8c.html#aef48d39f28b9c7fcb8d8f37a5482ea53',1,'Game_free(void):&#160;game.c'],['../game_8h.html#aef48d39f28b9c7fcb8d8f37a5482ea53',1,'Game_free(void):&#160;game.c']]],
  ['game_5finit_1',['Game_init',['../game_8c.html#a2886c1ccce89458ac3e60950e3a6feaa',1,'Game_init(void):&#160;game.c'],['../game_8h.html#a2886c1ccce89458ac3e60950e3a6feaa',1,'Game_init(void):&#160;game.c']]],
  ['game_5floop_2',['Game_loop',['../game_8c.html#a182e35027dfd61633b04ace81efa51dc',1,'Game_loop(void):&#160;game.c'],['../game_8h.html#a182e35027dfd61633b04ace81efa51dc',1,'Game_loop(void):&#160;game.c']]]
];
