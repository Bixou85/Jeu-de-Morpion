var searchData=
[
  ['squarechangecallback_0',['SquareChangeCallback',['../board_8h.html#ae390693d85e5b060c294023d835bdb2b',1,'board.h']]]
];
