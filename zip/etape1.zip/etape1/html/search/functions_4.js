var searchData=
[
  ['playermanager_5ffree_0',['PlayerManager_free',['../player__manager_8h.html#a23ee5b03794f57a020be47920e108278',1,'player_manager.h']]],
  ['playermanager_5finit_1',['PlayerManager_init',['../player__manager_8h.html#a952fb71cda52179fc0ee78d158b35c4b',1,'player_manager.h']]],
  ['playermanager_5foneturn_2',['PlayerManager_oneTurn',['../player__manager_8h.html#a2a1b236b2fe6dcdf791cc3e8ea2155e0',1,'player_manager.h']]]
];
