var searchData=
[
  ['none_0',['NONE',['../board_8h.html#a12ed9719bbdf7bc596ff7a6f4bf3f021ac157bdf0b85a40d2619cbc8bc1ae5fe2',1,'board.h']]]
];
