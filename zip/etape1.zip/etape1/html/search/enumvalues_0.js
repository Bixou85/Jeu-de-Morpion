var searchData=
[
  ['circle_0',['CIRCLE',['../board_8h.html#a12ed9719bbdf7bc596ff7a6f4bf3f021aa79c827759ea48f0735386c4b1188911',1,'board.h']]],
  ['circle_5fwins_1',['CIRCLE_WINS',['../board_8h.html#a41741953d704b743544ce6383c27c7c6a754bc2f0b0d988e5c2da7d1670213729',1,'board.h']]],
  ['cross_2',['CROSS',['../board_8h.html#a12ed9719bbdf7bc596ff7a6f4bf3f021ad699bdf1731bd839b56c299536ba1d9d',1,'board.h']]],
  ['cross_5fwins_3',['CROSS_WINS',['../board_8h.html#a41741953d704b743544ce6383c27c7c6aa27f913528645e7d6059540e77d5f49e',1,'board.h']]]
];
