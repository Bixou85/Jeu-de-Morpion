/**
 * @file main.c
 *
 * @date 27 oct. 2016
 * @author jilias
 */

#include "test_CheckEndOfGame.h"

int main (void)
{
	test_CheckEndOfGame ();

	return 0;
}
