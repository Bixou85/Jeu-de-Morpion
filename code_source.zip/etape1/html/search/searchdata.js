var indexSectionsWithContent =
{
  0: "bcdefgmnpst",
  1: "bgmpt",
  2: "bfgmp",
  3: "ces",
  4: "gp",
  5: "cdnps"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "enums",
  5: "enumvalues"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions",
  3: "Définitions de type",
  4: "Énumérations",
  5: "Valeurs énumérées"
};

