var searchData=
[
  ['fatalerror_0',['fatalError',['../tictactoe__errors_8c.html#a30c2018f7106b7740604db865aa13de9',1,'fatalError(const char *message):&#160;tictactoe_errors.c'],['../tictactoe__errors_8h.html#a30c2018f7106b7740604db865aa13de9',1,'fatalError(const char *message):&#160;tictactoe_errors.c']]]
];
