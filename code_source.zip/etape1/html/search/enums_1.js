var searchData=
[
  ['piecetype_0',['PieceType',['../board_8h.html#a12ed9719bbdf7bc596ff7a6f4bf3f021',1,'board.h']]],
  ['putpieceresult_1',['PutPieceResult',['../board_8h.html#a9644515bdbb420ad692c02d3ec8de111',1,'board.h']]]
];
