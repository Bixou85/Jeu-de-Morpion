var searchData=
[
  ['board_5ffree_0',['Board_free',['../board_8c.html#ae14a2975197c0bec0affc25a535dd1ab',1,'Board_free():&#160;board.c'],['../board_8h.html#ae14a2975197c0bec0affc25a535dd1ab',1,'Board_free():&#160;board.c']]],
  ['board_5fgetsquarecontent_1',['Board_getSquareContent',['../board_8c.html#ac5cb780c9613e01233bedfa958f1b8af',1,'Board_getSquareContent(Coordinate x, Coordinate y):&#160;board.c'],['../board_8h.html#ac5cb780c9613e01233bedfa958f1b8af',1,'Board_getSquareContent(Coordinate x, Coordinate y):&#160;board.c']]],
  ['board_5finit_2',['Board_init',['../board_8c.html#a01908f721c22cc7a2f149f266725805c',1,'Board_init(SquareChangeCallback onSquareChange, EndOfGameCallback onEndOfGame):&#160;board.c'],['../board_8h.html#a01908f721c22cc7a2f149f266725805c',1,'Board_init(SquareChangeCallback onSquareChange, EndOfGameCallback onEndOfGame):&#160;board.c']]],
  ['board_5fputpiece_3',['Board_putPiece',['../board_8c.html#adcaabd677f72247fc81c6ddd38696165',1,'Board_putPiece(Coordinate x, Coordinate y, PieceType kindOfPiece):&#160;board.c'],['../board_8h.html#adcaabd677f72247fc81c6ddd38696165',1,'Board_putPiece(Coordinate x, Coordinate y, PieceType kindOfPiece):&#160;board.c']]],
  ['boardview_5fdisplayall_4',['BoardView_displayAll',['../board__view_8h.html#af605f5fea5e1eefba9ea347978b788c4',1,'board_view.h']]],
  ['boardview_5fdisplayendofgame_5',['BoardView_displayEndOfGame',['../board__view_8h.html#a9385a34b71ebad776b4ed7aeb48f72d3',1,'board_view.h']]],
  ['boardview_5fdisplayplayersturn_6',['BoardView_displayPlayersTurn',['../board__view_8h.html#a55ef7f67d406f553602632425bde232a',1,'board_view.h']]],
  ['boardview_5fdisplaysquare_7',['BoardView_displaySquare',['../board__view_8h.html#a194c929d43a3043cf1a7a7ba767fffaa',1,'board_view.h']]],
  ['boardview_5ffree_8',['BoardView_free',['../board__view_8h.html#a4e43ae9add274f8e7e5e9af62138bc20',1,'board_view.h']]],
  ['boardview_5finit_9',['BoardView_init',['../board__view_8h.html#afa9be49293ac796482cc7104bdd585b9',1,'board_view.h']]],
  ['boardview_5fsaycannotputpiece_10',['BoardView_sayCannotPutPiece',['../board__view_8h.html#abe616e73b779409a73714521ebf7ffe7',1,'board_view.h']]]
];
